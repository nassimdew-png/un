<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use App\Models\Patient;
use App\Models\Tenant;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class KioskController extends Controller
{
    /**
     * Touchscreen Kiosk PIN check-in for patients in waiting room.
     */
    public function checkIn(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'kiosk_pin' => 'required|string|min:4|max:10',
                'subdomain' => 'nullable|string',
            ]);

            $pin = trim($validated['kiosk_pin']);
            $subdomain = $request->input('subdomain') ?: $request->header('X-Tenant-Subdomain');
            $tenantId = $request->header('X-Tenant-ID') ?: $request->header('X-Tenant');

            $tenant = null;
            if ($tenantId) {
                $tenant = Tenant::find($tenantId);
            }
            if (!$tenant && $subdomain) {
                $tenant = Tenant::where('subdomain', $subdomain)->first();
            }
            if (!$tenant) {
                $tenant = Tenant::first();
            }

            // Find patient by PIN
            $patientQuery = Patient::withoutGlobalScopes()->where('kiosk_pin', $pin);
            if ($tenant) {
                $patient = (clone $patientQuery)->where('tenant_id', $tenant->id)->first();
                if (!$patient) {
                    $patient = $patientQuery->first();
                }
            } else {
                $patient = $patientQuery->first();
            }

            if (!$patient) {
                return response()->json([
                    'success' => false,
                    'message' => 'رمز التحقق (PIN) غير صحيح أو غير مسجل. يرجى التأكد من الرمز أو التوجه لمكتب الاستقبال. (Code PIN introuvable)',
                ], 404);
            }

            $effectiveTenantId = $patient->tenant_id ?: ($tenant ? $tenant->id : null);
            $today = Carbon::today()->toDateString();

            // Check today's appointment
            $appointmentQuery = Appointment::withoutGlobalScopes()
                ->where('patient_id', $patient->id)
                ->whereDate('appointment_date', $today);

            if ($effectiveTenantId) {
                $appointmentQuery->where('tenant_id', $effectiveTenantId);
            }

            $appointment = $appointmentQuery->first();

            if ($appointment) {
                $appointment->update([
                    'status' => 'confirmed',
                ]);
            } else {
                // Register instant walk-in / arrival for waiting room queue
                $specialistId = $patient->assigned_practitioner_id;
                if (!$specialistId && $tenant) {
                    $specialistId = $tenant->users()->first()?->id;
                }

                $appointment = Appointment::withoutGlobalScopes()->create([
                    'tenant_id' => $effectiveTenantId,
                    'patient_id' => $patient->id,
                    'specialist_id' => $specialistId ?: 1,
                    'appointment_date' => Carbon::now(),
                    'type' => 'walk_in',
                    'status' => 'confirmed',
                    'notes' => 'تسجيل حضور ذاتي عبر الشاشة التفاعلية (Kiosk Check-in)',
                ]);
            }

            $clinicName = $tenant ? $tenant->name : 'ClinicSaaS DZ';
            $appointmentTime = $appointment && $appointment->appointment_date
                ? Carbon::parse($appointment->appointment_date)->format('H:i')
                : Carbon::now()->format('H:i');

            return response()->json([
                'success' => true,
                'message' => sprintf('مرحباً بك %s %s ! تم تسجيل وصولك في قاعة الانتظار بنجاح. (Bienvenue ! Votre arrivée a été signalée)', $patient->first_name, $patient->last_name),
                'patient' => [
                    'id' => $patient->id,
                    'name' => $patient->first_name . ' ' . $patient->last_name,
                    'appointment_time' => $appointmentTime,
                    'status' => 'Arrivée confirmée en salle d attente',
                ],
                'clinic' => $clinicName,
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'يرجى إدخال رمز PIN صالح مكون من 6 أرقام.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Throwable $e) {
            Log::error('Kiosk check-in error: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return response()->json([
                'success' => false,
                'message' => 'تعذر إتمام تسجيل الحضور حالياً. يرجى التوجه لمكتب الاستقبال.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
