import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Building2,
  Globe,
  Save,
  Palette,
  Phone,
  MapPin,
  FileText,
  Key,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Monitor,
  Upload,
  Image as ImageIcon,
  Stamp,
  PenTool,
  Trash2,
  Eye,
  EyeOff,
  Layers,
  Layout,
  SlidersHorizontal,
  Check,
  RefreshCw,
  Printer,
  Shield,
  Award,
  User,
  Mail,
  UserCheck,
  Lock
} from 'lucide-react';
import { clinicBrandingApi, userProfileApi } from '../../api';

export default function ClinicSettingsView({ tenant, user }) {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('branding'); // 'branding' | 'profile'

  // ==========================================
  // 1. BRANDING & A4 EN-TÊTE STATE
  // ==========================================
  const [formData, setFormData] = useState({
    name: tenant?.name || 'عيادة الأمل للأرطوفونيا وعلم النفس',
    license_number: 'DZ-MSPRH-2026/884',
    official_title_ar: 'عيادة ومخبر الفحوصات والتشخيص السريري والتأهيلي',
    official_title_fr: 'Cabinet Médical Spécialisé en Orthophonie et Psychologie',
    phone: tenant?.phone || '0559 22 33 44',
    address: tenant?.address || 'حي 500 مسكن - عمارة B، بئر مراد رايس',
    wilaya: tenant?.wilaya || '16 - الجزائر العاصمة',
    primary_color: '#2563eb',
    secondary_color: '#06b6d4',
    header_layout: 'modern_split', // 'modern_split' | 'centered_minimal' | 'classic_boxed'
    show_watermark: true,
    show_stamp_on_bilans: true,
    kiosk_pin: '1234',
    kiosk_enabled: true,
    reassessment_days_threshold: 90,
    footer_text: 'وثيقة طبية وسريرية رسمية صادرة عن منظومة السجلات الرقمية PsyPro Tech • صالحة للإجراءات الإدارية والمدرسية',
  });

  // Files state
  const [logoFile, setLogoFile] = useState(null);
  const [logoPreview, setLogoPreview] = useState(null);
  const [stampFile, setStampFile] = useState(null);
  const [stampPreview, setStampPreview] = useState(null);
  const [signatureFile, setSignatureFile] = useState(null);
  const [signaturePreview, setSignaturePreview] = useState(null);

  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState(null);

  const logoInputRef = useRef(null);
  const stampInputRef = useRef(null);
  const signatureInputRef = useRef(null);

  // ==========================================
  // 2. PRACTITIONER PROFILE & SECURITY STATE
  // ==========================================
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    specialty: user?.specialty || 'أخصائي أرطوفونيا وتخاطب (Orthophoniste)',
    specialty_license_number: user?.specialty_license_number || '',
    role: user?.role || 'clinic_admin',
  });

  const [passwordData, setPasswordData] = useState({
    current_password: '',
    new_password: '',
    new_password_confirmation: '',
  });

  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [savingProfile, setSavingProfile] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);
  const [profileFeedback, setProfileFeedback] = useState(null);
  const [passwordFeedback, setPasswordFeedback] = useState(null);

  const specialtyPresets = [
    'أخصائي أرطوفونيا وتخاطب (Orthophoniste)',
    'طبيب / أخصائي نفساني عيادي (Psychologue Clinicien)',
    'أخصائي نفسي حركي (Psychomotricien)',
    'طبيب نفسي / أعصاب (Neuro-Psychiatre)',
    'أخصائي علاج وظيفي (Ergothérapeute)',
    'مربي ومعالج سلوكي (Éducateur Spécialisé / ABA)',
    'طبيب عام واستشارات طبية (Médecin Généraliste)',
  ];

  const colorPresets = [
    { name: 'أزرق ملكي', primary: '#2563eb', secondary: '#06b6d4' },
    { name: 'فيروزي سريري', primary: '#0d9488', secondary: '#14b8a6' },
    { name: 'نيلي طبي', primary: '#4f46e5', secondary: '#818cf8' },
    { name: 'زمردي صحي', primary: '#059669', secondary: '#34d399' },
    { name: 'بنفسجي راقٍ', primary: '#7c3aed', secondary: '#c084fc' },
    { name: 'كحلي داكن', primary: '#0f172a', secondary: '#475569' },
  ];

  // Fetch Branding and User Profile
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [brandingRes, profileRes] = await Promise.allSettled([
          clinicBrandingApi.getBranding(),
          userProfileApi.getProfile(),
        ]);

        if (brandingRes.status === 'fulfilled' && brandingRes.value?.settings) {
          const res = brandingRes.value;
          setFormData((prev) => ({
            ...prev,
            ...res.settings,
            name: res.tenant?.name || prev.name,
          }));
          if (res.settings.logo_url) setLogoPreview(res.settings.logo_url);
          if (res.settings.stamp_url) setStampPreview(res.settings.stamp_url);
          if (res.settings.signature_url) setSignaturePreview(res.settings.signature_url);
        }

        if (profileRes.status === 'fulfilled' && profileRes.value?.user) {
          const u = profileRes.value.user;
          setProfileData({
            name: u.name || '',
            email: u.email || '',
            phone: u.phone || '',
            specialty: u.specialty || 'أخصائي أرطوفونيا وتخاطب (Orthophoniste)',
            specialty_license_number: u.specialty_license_number || '',
            role: u.role || 'clinic_admin',
          });
        }
      } catch (err) {
        console.error('Failed to load settings data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Branding Handlers
  const handleLogoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setLogoFile(file);
      setLogoPreview(URL.createObjectURL(file));
    }
  };

  const handleStampChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setStampFile(file);
      setStampPreview(URL.createObjectURL(file));
    }
  };

  const handleSignatureChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setSignatureFile(file);
      setSignaturePreview(URL.createObjectURL(file));
    }
  };

  const handleRemoveLogo = () => {
    setLogoFile(null);
    setLogoPreview(null);
    setFormData((prev) => ({ ...prev, logo_url: 'DELETE' }));
  };

  const handleRemoveStamp = () => {
    setStampFile(null);
    setStampPreview(null);
    setFormData((prev) => ({ ...prev, stamp_url: 'DELETE' }));
  };

  const handleRemoveSignature = () => {
    setSignatureFile(null);
    setSignaturePreview(null);
    setFormData((prev) => ({ ...prev, signature_url: 'DELETE' }));
  };

  const handleBrandingSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setFeedback(null);

    try {
      const data = new FormData();
      Object.keys(formData).forEach((key) => {
        data.append(key, formData[key]);
      });

      if (logoFile) data.append('logo', logoFile);
      if (stampFile) data.append('stamp', stampFile);
      if (signatureFile) data.append('signature', signatureFile);

      const res = await clinicBrandingApi.updateBranding(data);
      setFeedback({ type: 'success', text: res.message || 'تم حفظ وتطبيق الهوية البصرية بنجاح!' });

      if (res.settings) {
        if (res.settings.logo_url) setLogoPreview(res.settings.logo_url);
        if (res.settings.stamp_url) setStampPreview(res.settings.stamp_url);
        if (res.settings.signature_url) setSignaturePreview(res.settings.signature_url);
      }
    } catch (err) {
      console.error('Save failed:', err);
      setFeedback({ type: 'error', text: err.message || 'فشل حفظ الإعدادات.' });
    } finally {
      setSaving(false);
    }
  };

  // Practitioner Profile Handlers
  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    setSavingProfile(true);
    setProfileFeedback(null);

    try {
      const res = await userProfileApi.updateProfile({
        name: profileData.name,
        email: profileData.email,
        phone: profileData.phone,
        specialty: profileData.specialty,
        specialty_license_number: profileData.specialty_license_number,
      });

      setProfileFeedback({ type: 'success', text: res.message || 'تم تحديث بيانات الملف الشخصي بنجاح!' });
      
      // Update local storage user if present
      const storedUser = localStorage.getItem('user');
      if (storedUser) {
        try {
          const parsed = JSON.parse(storedUser);
          localStorage.setItem('user', JSON.stringify({ ...parsed, ...res.user }));
        } catch {}
      }
    } catch (err) {
      console.error('Profile update failed:', err);
      setProfileFeedback({ type: 'error', text: err.message || 'فشل تحديث الملف الشخصي. يرجى التأكد من صحة البريد الإلكتروني.' });
    } finally {
      setSavingProfile(false);
    }
  };

  const handleUpdatePassword = async (e) => {
    e.preventDefault();
    setPasswordFeedback(null);

    if (passwordData.new_password.length < 6) {
      setPasswordFeedback({ type: 'error', text: 'كلمة المرور الجديدة يجب أن تتكون من 6 أحرف على الأقل.' });
      return;
    }

    if (passwordData.new_password !== passwordData.new_password_confirmation) {
      setPasswordFeedback({ type: 'error', text: 'تأكيد كلمة المرور الجديدة غير متطابق.' });
      return;
    }

    setSavingPassword(true);

    try {
      const res = await userProfileApi.updatePassword({
        current_password: passwordData.current_password,
        new_password: passwordData.new_password,
        new_password_confirmation: passwordData.new_password_confirmation,
      });

      setPasswordFeedback({ type: 'success', text: res.message || 'تم تغيير كلمة المرور بنجاح وحماية الحساب!' });
      setPasswordData({
        current_password: '',
        new_password: '',
        new_password_confirmation: '',
      });
    } catch (err) {
      console.error('Password update failed:', err);
      setPasswordFeedback({ type: 'error', text: err.message || 'فشل تغيير كلمة المرور. تأكد من كلمة المرور الحالية.' });
    } finally {
      setSavingPassword(false);
    }
  };

  return (
    <div className="space-y-6 font-sans text-right" dir="rtl">
      {/* Header Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/70 to-slate-950 border border-indigo-500/30 shadow-2xl space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2 space-x-reverse">
              <span className="px-3 py-1 rounded-full text-[11px] font-black bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                <span>CLINIC SETTINGS & PRACTITIONER SECURITY</span>
              </span>
              <span className="text-xs font-mono text-emerald-400 font-bold bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20">
                {activeTab === 'branding' ? 'A4 Live Preview 📄' : 'Security Active 🔒'}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">
              {activeTab === 'branding' ? 'إعدادات العيادة وترويسة التقارير الطبية' : 'الملف الشخصي وأمان حساب المختص'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
              {activeTab === 'branding'
                ? 'تحكم بهوية العيادة، رفع الشعار عالي الدقة، الختم الطبي الرقمي، التوقيع، وتخصيص ترويسة الحصائل والوصفات الطبية (A4) مع معاينة حية لحظية.'
                : 'إدارة وتحديث بيانات الطبيب/الأخصائي، البريد الإلكتروني، رقم الهاتف، رخصة الممارسة، وتغيير كلمة المرور المشفرة.'}
            </p>
          </div>

          <div className="flex items-center gap-2.5 self-start md:self-auto shrink-0 flex-wrap">
            <button
              type="button"
              onClick={() => navigate('/settings/domains')}
              className="px-4 py-3 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 text-xs font-bold transition flex items-center space-x-2 space-x-reverse"
            >
              <Globe className="w-4 h-4" />
              <span>🌐 النطاق المخصص وSSL</span>
            </button>

            {activeTab === 'branding' && (
              <button
                onClick={handleBrandingSubmit}
                disabled={saving}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white text-xs font-black transition flex items-center space-x-2 space-x-reverse shadow-xl shadow-indigo-600/30"
              >
                <Save className="w-4 h-4" />
                <span>{saving ? 'جاري الحفظ...' : '💾 حفظ وتطبيق الهوية'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Tab Navigation Pill Bar */}
        <div className="flex items-center space-x-2 space-x-reverse pt-2 border-t border-slate-800/80">
          <button
            type="button"
            onClick={() => setActiveTab('branding')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 space-x-reverse ${
              activeTab === 'branding'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 border border-indigo-400'
                : 'bg-slate-900/90 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Palette className="w-4 h-4" />
            <span>🎨 الهوية البصرية وترويسة A4</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('profile')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 space-x-reverse ${
              activeTab === 'profile'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 border border-indigo-400'
                : 'bg-slate-900/90 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>👤 الملف المهني وأمان كلمة المرور</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: BRANDING & A4 LIVE STUDIO                                         */}
      {/* ========================================================================= */}
      {activeTab === 'branding' && (
        <>
          {feedback && (
            <div
              className={`p-4 rounded-2xl border text-xs font-bold flex items-center justify-between shadow-lg ${
                feedback.type === 'success'
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
              }`}
            >
              <span className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                {feedback.text}
              </span>
              <button onClick={() => setFeedback(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>
          )}

          {/* Main Split Studio Layout: Form on Right, A4 Live Canvas on Left */}
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
            {/* RIGHT PANEL: Controls & Uploads (7 Cols on XL) */}
            <div className="xl:col-span-7 space-y-6">
              <form onSubmit={handleBrandingSubmit} className="space-y-6">
                {/* 1. Upload Assets Card */}
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-xl">
                  <h2 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
                    <Upload className="w-4 h-4 text-indigo-400" />
                    <span>1. الأصول البصرية (الشعار، الختم الطبي، التوقيع)</span>
                  </h2>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {/* Logo Upload */}
                    <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 flex flex-col justify-between items-center text-center space-y-3">
                      <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                        <ImageIcon className="w-4 h-4 text-indigo-400" />
                        <span>شعار العيادة (Logo)</span>
                      </div>

                      <div className="w-20 h-20 rounded-2xl border-2 border-dashed border-slate-700 hover:border-indigo-500 flex items-center justify-center overflow-hidden relative bg-slate-900 group">
                        {logoPreview ? (
                          <img src={logoPreview} alt="Logo" className="w-full h-full object-contain p-1" />
                        ) : (
                          <span className="text-[10px] text-slate-500 font-bold">لا يوجد شعار</span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 w-full">
                        <input
                          type="file"
                          ref={logoInputRef}
                          onChange={handleLogoChange}
                          accept="image/*"
                          className="hidden"
                        />
                        <button
                          type="button"
                          onClick={() => logoInputRef.current?.click()}
                          className="flex-1 py-1.5 px-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-[11px] font-bold transition"
                        >
                          رفع شعار
                        </button>
                        {logoPreview && (
                          <button
                            type="button"
                            onClick={handleRemoveLogo}
                            className="p-1.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 transition"
                            title="حذف الشعار"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Stamp Upload */}
                    <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 flex flex-col justify-between items-center text-center space-y-3">
                      <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                        <Stamp className="w-4 h-4 text-indigo-400" />
                        <span>الختم الدائري (Cachet)</span>
                      </div>

                      <div className="w-20 h-20 rounded-full border-2 border-dashed border-slate-700 hover:border-indigo-500 flex items-center justify-center overflow-hidden relative bg-slate-900 group">
                        {stampPreview ? (
                          <img src={stampPreview} alt="Stamp" className="w-full h-full object-contain p-1" />
                        ) : (
                          <span className="text-[10px] text-slate-500 font-bold">لا يوجد ختم</span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 w-full">
                        <input
                          type="file"
                          ref={stampInputRef}
                          onChange={handleStampChange}
                          accept="image/*"
                          className="hidden"
                        />
                        <button
                          type="button"
                          onClick={() => stampInputRef.current?.click()}
                          className="flex-1 py-1.5 px-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-[11px] font-bold transition"
                        >
                          رفع الختم
                        </button>
                        {stampPreview && (
                          <button
                            type="button"
                            onClick={handleRemoveStamp}
                            className="p-1.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 transition"
                            title="حذف الختم"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Signature Upload */}
                    <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 flex flex-col justify-between items-center text-center space-y-3">
                      <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                        <PenTool className="w-4 h-4 text-indigo-400" />
                        <span>توقيع الطبيب المشرف</span>
                      </div>

                      <div className="w-24 h-16 rounded-2xl border-2 border-dashed border-slate-700 hover:border-indigo-500 flex items-center justify-center overflow-hidden relative bg-slate-900 group">
                        {signaturePreview ? (
                          <img src={signaturePreview} alt="Signature" className="w-full h-full object-contain p-1" />
                        ) : (
                          <span className="text-[10px] text-slate-500 font-bold">لا يوجد توقيع</span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 w-full">
                        <input
                          type="file"
                          ref={signatureInputRef}
                          onChange={handleSignatureChange}
                          accept="image/*"
                          className="hidden"
                        />
                        <button
                          type="button"
                          onClick={() => signatureInputRef.current?.click()}
                          className="flex-1 py-1.5 px-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-[11px] font-bold transition"
                        >
                          رفع التوقيع
                        </button>
                        {signaturePreview && (
                          <button
                            type="button"
                            onClick={handleRemoveSignature}
                            className="p-1.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 transition"
                            title="حذف التوقيع"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* 2. Official Clinical Information */}
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-xl">
                  <h2 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
                    <Building2 className="w-4 h-4 text-indigo-400" />
                    <span>2. البيانات الرسمية للعيادة والترخيص</span>
                  </h2>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div className="space-y-1.5">
                      <label className="text-slate-300 font-bold">اسم العيادة / المركز الطبي الرسمي</label>
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-indigo-500 text-white font-medium focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-slate-300 font-bold">رقم الاعتماد / رخصة الممارسة (MSPRH)</label>
                      <input
                        type="text"
                        value={formData.license_number}
                        onChange={(e) => setFormData({ ...formData, license_number: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-indigo-500 text-white font-medium focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-slate-300 font-bold">الصفة واللقب الرسمي (بالعربية)</label>
                      <input
                        type="text"
                        value={formData.official_title_ar}
                        onChange={(e) => setFormData({ ...formData, official_title_ar: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-indigo-500 text-white font-medium focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-slate-300 font-bold">الصفة واللقب الرسمي (بالفرنسية)</label>
                      <input
                        type="text"
                        value={formData.official_title_fr}
                        onChange={(e) => setFormData({ ...formData, official_title_fr: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-indigo-500 text-white font-medium focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-slate-300 font-bold">هاتف العيادة المباشر</label>
                      <input
                        type="text"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-indigo-500 text-white font-medium focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-slate-300 font-bold">الولاية والموقع</label>
                      <input
                        type="text"
                        value={formData.wilaya}
                        onChange={(e) => setFormData({ ...formData, wilaya: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-indigo-500 text-white font-medium focus:outline-none"
                      />
                    </div>

                    <div className="sm:col-span-2 space-y-1.5">
                      <label className="text-slate-300 font-bold">العنوان التفصيلي للعيادة</label>
                      <input
                        type="text"
                        value={formData.address}
                        onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-indigo-500 text-white font-medium focus:outline-none"
                      />
                    </div>

                    <div className="sm:col-span-2 space-y-1.5">
                      <label className="text-slate-300 font-bold">نص التذييل القانوني في أسفل التقارير (Footer Note)</label>
                      <textarea
                        rows={2}
                        value={formData.footer_text}
                        onChange={(e) => setFormData({ ...formData, footer_text: e.target.value })}
                        className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-indigo-500 text-white font-medium focus:outline-none text-xs"
                      />
                    </div>
                  </div>
                </div>

                {/* 3. Color Palette & Layout Styles */}
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-xl">
                  <h2 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
                    <Palette className="w-4 h-4 text-indigo-400" />
                    <span>3. لوحة الألوان والنسق البصري للترويسة</span>
                  </h2>

                  <div className="space-y-4">
                    {/* Color Presets */}
                    <div>
                      <span className="text-xs text-slate-400 font-bold block mb-2">نماذج الألوان المعتمدة:</span>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                        {colorPresets.map((preset) => (
                          <button
                            key={preset.name}
                            type="button"
                            onClick={() => setFormData({ ...formData, primary_color: preset.primary, secondary_color: preset.secondary })}
                            className={`p-2.5 rounded-xl border flex items-center justify-between transition ${
                              formData.primary_color === preset.primary
                                ? 'border-indigo-500 bg-indigo-500/10'
                                : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
                            }`}
                          >
                            <span className="text-xs font-bold text-slate-200">{preset.name}</span>
                            <div className="flex items-center space-x-1 space-x-reverse">
                              <span className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: preset.primary }} />
                              <span className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: preset.secondary }} />
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Layout Format Selector */}
                    <div>
                      <span className="text-xs text-slate-400 font-bold block mb-2">نمط تصميم الترويسة (Header Layout):</span>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <button
                          type="button"
                          onClick={() => setFormData({ ...formData, header_layout: 'modern_split' })}
                          className={`p-3 rounded-2xl border text-right transition ${
                            formData.header_layout === 'modern_split'
                              ? 'border-indigo-500 bg-indigo-500/10 text-white'
                              : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                          }`}
                        >
                          <div className="font-bold text-xs mb-1">عصري منقسم (Modern Split)</div>
                          <div className="text-[10px] text-slate-400">شعار على الطرفين مع خط تدرج لوني طبي</div>
                        </button>

                        <button
                          type="button"
                          onClick={() => setFormData({ ...formData, header_layout: 'centered_minimal' })}
                          className={`p-3 rounded-2xl border text-right transition ${
                            formData.header_layout === 'centered_minimal'
                              ? 'border-indigo-500 bg-indigo-500/10 text-white'
                              : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                          }`}
                        >
                          <div className="font-bold text-xs mb-1">مركزي ناعم (Centered Minimal)</div>
                          <div className="text-[10px] text-slate-400">شعار في الوسط وعناوين رأسية أنيقة</div>
                        </button>

                        <button
                          type="button"
                          onClick={() => setFormData({ ...formData, header_layout: 'classic_boxed' })}
                          className={`p-3 rounded-2xl border text-right transition ${
                            formData.header_layout === 'classic_boxed'
                              ? 'border-indigo-500 bg-indigo-500/10 text-white'
                              : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                          }`}
                        >
                          <div className="font-bold text-xs mb-1">كلاسيكي مؤطر (Classic Boxed)</div>
                          <div className="text-[10px] text-slate-400">إطار كلاسيكي مزدوج مناسب للمستشفيات</div>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>

            {/* LEFT PANEL: Live A4 Document Canvas Preview (5 Cols on XL) */}
            <div className="xl:col-span-5 sticky top-6 space-y-3">
              <div className="flex items-center justify-between px-2">
                <span className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
                  <Eye className="w-4 h-4 text-indigo-400" />
                  <span>معاينة حية للترويسة في الحصائل (A4 Real-time)</span>
                </span>
                <span className="text-[11px] font-mono text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                  Format A4 Standard
                </span>
              </div>

              {/* A4 Paper Mockup (White Paper Clinical Preview) */}
              <div className="w-full bg-white rounded-3xl p-6 sm:p-8 shadow-2xl text-slate-900 border border-slate-300 relative overflow-hidden font-sans min-h-[620px] flex flex-col justify-between">
                {/* Watermark Logo in Paper Background */}
                {formData.show_watermark && logoPreview && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5">
                    <img src={logoPreview} alt="Watermark" className="w-72 h-72 object-contain" />
                  </div>
                )}

                {/* Header Preview according to chosen layout */}
                <div>
                  {formData.header_layout === 'modern_split' && (
                    <div className="border-b-2 pb-4 space-y-2" style={{ borderColor: formData.primary_color }}>
                      <div className="flex items-start justify-between gap-4">
                        {/* Right Details (Arabic) */}
                        <div className="space-y-0.5 text-right">
                          <h2 className="text-sm font-black tracking-tight" style={{ color: formData.primary_color }}>
                            {formData.name}
                          </h2>
                          <div className="text-[10px] font-bold text-slate-700">{formData.official_title_ar}</div>
                          <div className="text-[9px] font-mono text-slate-500">رقم الاعتماد: {formData.license_number}</div>
                        </div>

                        {/* Center/Left Logo */}
                        <div className="flex items-center gap-3">
                          {logoPreview && (
                            <img src={logoPreview} alt="Logo" className="w-14 h-14 object-contain" />
                          )}
                        </div>

                        {/* Left Details (French) */}
                        <div className="space-y-0.5 text-left font-sans" dir="ltr">
                          <div className="text-[11px] font-black text-slate-800">RÉPUBLIQUE ALGÉRIENNE</div>
                          <div className="text-[9px] font-semibold text-slate-600">{formData.official_title_fr}</div>
                          <div className="text-[8px] text-slate-500">Tél: {formData.phone}</div>
                        </div>
                      </div>

                      {/* Aesthetic Gradient Divider */}
                      <div
                        className="h-1 rounded-full w-full"
                        style={{
                          background: `linear-gradient(to right, ${formData.primary_color}, ${formData.secondary_color})`,
                        }}
                      />
                    </div>
                  )}

                  {formData.header_layout === 'centered_minimal' && (
                    <div className="text-center pb-4 border-b space-y-2 border-slate-300">
                      {logoPreview && (
                        <img src={logoPreview} alt="Logo" className="w-16 h-16 object-contain mx-auto" />
                      )}
                      <h2 className="text-base font-black" style={{ color: formData.primary_color }}>
                        {formData.name}
                      </h2>
                      <div className="text-[10px] font-bold text-slate-700">
                        {formData.official_title_ar} &bull; {formData.official_title_fr}
                      </div>
                      <div className="text-[9px] font-mono text-slate-500">
                        الجمهورية الجزائرية الديمقراطية الشعبية &bull; رخصة رقم: {formData.license_number}
                      </div>
                    </div>
                  )}

                  {formData.header_layout === 'classic_boxed' && (
                    <div className="border-2 p-3 rounded-xl mb-4 border-slate-800 space-y-1 text-center">
                      <div className="flex items-center justify-between">
                        {logoPreview && <img src={logoPreview} alt="Logo" className="w-12 h-12 object-contain" />}
                        <div>
                          <h2 className="text-sm font-black text-slate-900">{formData.name}</h2>
                          <div className="text-[10px] font-bold">{formData.official_title_ar}</div>
                        </div>
                        <div className="w-12" />
                      </div>
                      <div className="text-[8px] text-slate-600 border-t pt-1 mt-1 border-slate-300">
                        رخصة الاعتماد: {formData.license_number} &bull; {formData.address}
                      </div>
                    </div>
                  )}

                  {/* Dummy Medical Report Body Content for Preview */}
                  <div className="py-4 space-y-3 text-[10px] text-slate-800 leading-relaxed">
                    <div className="flex items-center justify-between bg-slate-100 p-2.5 rounded-lg font-bold border border-slate-200">
                      <span>اسم المريض: يانيس بن علي (6 سنوات)</span>
                      <span>تاريخ الحصيلة: {new Date().toLocaleDateString('ar-DZ')}</span>
                    </div>

                    <div className="font-bold flex items-center gap-1" style={{ color: formData.primary_color }}>
                      <span>📋 التقييم والتشخيص السريري (Bilan Orthophonique):</span>
                    </div>
                    <p className="bg-slate-50/50 p-2 rounded-lg border border-slate-100">
                      أظهرت نتائج الاختبارات المقننة (SSI-4 و رائز الفونولوجيا) وجود اضطراب في طلاقة الكلام بمستوى متوسط، مصحوب بوقفات لاإرادية أثناء القراءة الجهرية مع مرونة لسانية ممتازة.
                    </p>

                    <div className="font-bold flex items-center gap-1 pt-1" style={{ color: formData.primary_color }}>
                      <span>🎯 التوصيات والخطة العلاجية المقترحة:</span>
                    </div>
                    <p className="bg-slate-50/50 p-2 rounded-lg border border-slate-100">
                      يوصى ببدء برنامج التأهيل الصوتي (Easy Onset) بمعدل حصتين أسبوعياً مع متابعة تمارين التنفس الحجابي المنزلية بالتنسيق مع الأولياء.
                    </p>
                  </div>
                </div>

                {/* Document Footer Section with Stamp & Signature */}
                <div className="relative z-10 pt-3 border-t border-slate-200 space-y-2">
                  <div className="flex items-end justify-between px-2">
                    <div className="text-center space-y-1">
                      <div className="text-[9px] font-bold text-slate-700">توقيع وختم الطبيب المشرف</div>
                      <div className="w-20 h-12 rounded-lg border border-dashed border-slate-300 flex items-center justify-center overflow-hidden bg-slate-50 relative">
                        {signaturePreview ? (
                          <img src={signaturePreview} alt="Signature" className="w-full h-full object-contain" />
                        ) : (
                          <span className="text-[7px] text-slate-400">توقيع الطبيب</span>
                        )}
                      </div>
                    </div>

                    {formData.show_stamp_on_bilans && (
                      <div className="text-center space-y-1">
                        <div className="text-[9px] font-bold text-slate-700">الختم الطبي الرسمي</div>
                        <div className="w-16 h-16 rounded-full border border-dashed border-slate-300 flex items-center justify-center overflow-hidden bg-slate-50 relative">
                          {stampPreview ? (
                            <img src={stampPreview} alt="Stamp" className="w-full h-full object-contain" />
                          ) : (
                            <span className="text-[7px] text-slate-400">الختم الدائري</span>
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Legal Footer Notice */}
                  <div className="text-center pt-2 border-t border-slate-100 text-[8px] text-slate-500 leading-tight">
                    <div>{formData.address} • {formData.wilaya} • هاتف: {formData.phone}</div>
                    <div className="text-[7px] text-slate-400 mt-0.5">{formData.footer_text}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: PRACTITIONER PROFILE & SECURITY SETTINGS                           */}
      {/* ========================================================================= */}
      {activeTab === 'profile' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* LEFT/MAIN: Personal Info & Password Forms (8 Cols) */}
          <div className="lg:col-span-8 space-y-6">
            {/* 1. Practitioner Personal & Professional Details Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center space-x-3 space-x-reverse">
                  <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center border border-indigo-500/20">
                    <User className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-base font-black text-white">البيانات الشخصية والمهنية للمختص</h2>
                    <p className="text-xs text-slate-400">تعديل الاسم، البريد الإلكتروني، رقم الهاتف، والتخصص الطبي</p>
                  </div>
                </div>
              </div>

              {profileFeedback && (
                <div
                  className={`p-4 rounded-2xl border text-xs font-bold flex items-center justify-between shadow-lg ${
                    profileFeedback.type === 'success'
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                      : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    {profileFeedback.text}
                  </span>
                  <button onClick={() => setProfileFeedback(null)} className="text-slate-400 hover:text-white">✕</button>
                </div>
              )}

              <form onSubmit={handleUpdateProfile} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  {/* Name */}
                  <div className="space-y-1.5">
                    <label className="text-slate-300 font-bold flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-indigo-400" />
                      <span>الاسم واللقب الكامل</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={profileData.name}
                      onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                      placeholder="د. أمينة بن علي"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-indigo-500 text-white font-medium focus:outline-none text-xs"
                    />
                  </div>

                  {/* Email */}
                  <div className="space-y-1.5">
                    <label className="text-slate-300 font-bold flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-indigo-400" />
                      <span>البريد الإلكتروني (لتسجيل الدخول)</span>
                    </label>
                    <input
                      type="email"
                      required
                      value={profileData.email}
                      onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                      placeholder="doctor@clinic.dz"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-indigo-500 text-white font-medium focus:outline-none text-xs text-left"
                      dir="ltr"
                    />
                  </div>

                  {/* Phone */}
                  <div className="space-y-1.5">
                    <label className="text-slate-300 font-bold flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-indigo-400" />
                      <span>رقم الهاتف المباشر</span>
                    </label>
                    <input
                      type="text"
                      value={profileData.phone}
                      onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                      placeholder="0550 12 34 56"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-indigo-500 text-white font-medium focus:outline-none text-xs text-left"
                      dir="ltr"
                    />
                  </div>

                  {/* License Number */}
                  <div className="space-y-1.5">
                    <label className="text-slate-300 font-bold flex items-center gap-1.5">
                      <Award className="w-3.5 h-3.5 text-indigo-400" />
                      <span>رقم الاعتماد / الرخصة المهنية للمختص</span>
                    </label>
                    <input
                      type="text"
                      value={profileData.specialty_license_number}
                      onChange={(e) => setProfileData({ ...profileData, specialty_license_number: e.target.value })}
                      placeholder="DZ-ORD-2026-908"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-indigo-500 text-white font-medium focus:outline-none text-xs text-left"
                      dir="ltr"
                    />
                  </div>

                  {/* Specialty Dropdown / Custom */}
                  <div className="sm:col-span-2 space-y-1.5">
                    <label className="text-slate-300 font-bold flex items-center justify-between">
                      <span>التخصص السريري والمهني</span>
                      <span className="text-[10px] text-slate-500 font-normal">يظهر في تقارير وتوقيعات الحصائل</span>
                    </label>
                    <select
                      value={specialtyPresets.includes(profileData.specialty) ? profileData.specialty : 'custom'}
                      onChange={(e) => {
                        if (e.target.value !== 'custom') {
                          setProfileData({ ...profileData, specialty: e.target.value });
                        }
                      }}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-indigo-500 text-white font-medium focus:outline-none text-xs"
                    >
                      {specialtyPresets.map((sp) => (
                        <option key={sp} value={sp} className="bg-slate-900 text-slate-200">{sp}</option>
                      ))}
                      <option value="custom" className="bg-slate-900 text-slate-200">✍️ تخصص آخر مخصص...</option>
                    </select>

                    {(!specialtyPresets.includes(profileData.specialty) || profileData.specialty === '') && (
                      <input
                        type="text"
                        value={profileData.specialty}
                        onChange={(e) => setProfileData({ ...profileData, specialty: e.target.value })}
                        placeholder="اكتب مسمى تخصصك السريري بالتفصيل..."
                        className="w-full mt-2 px-3.5 py-2.5 rounded-xl bg-slate-950 border border-indigo-500/50 text-white font-medium focus:outline-none text-xs"
                      />
                    )}
                  </div>
                </div>

                <div className="pt-3 flex justify-end">
                  <button
                    type="submit"
                    disabled={savingProfile}
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white text-xs font-black transition flex items-center space-x-2 space-x-reverse shadow-lg shadow-indigo-600/20 disabled:opacity-50"
                  >
                    <Save className="w-4 h-4" />
                    <span>{savingProfile ? 'جاري الحفظ...' : 'حفظ البيانات المهنية'}</span>
                  </button>
                </div>
              </form>
            </div>

            {/* 2. Password & Security Management Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center space-x-3 space-x-reverse">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-400 flex items-center justify-center border border-amber-500/20">
                    <Lock className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-base font-black text-white">تغيير كلمة المرور وأمان الحساب</h2>
                    <p className="text-xs text-slate-400">تحديث كلمة السر بآلية مشفرة لحماية السجلات الطبية والسريرية</p>
                  </div>
                </div>
              </div>

              {passwordFeedback && (
                <div
                  className={`p-4 rounded-2xl border text-xs font-bold flex items-center justify-between shadow-lg ${
                    passwordFeedback.type === 'success'
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                      : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    {passwordFeedback.type === 'success' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-rose-400" />
                    )}
                    {passwordFeedback.text}
                  </span>
                  <button onClick={() => setPasswordFeedback(null)} className="text-slate-400 hover:text-white">✕</button>
                </div>
              )}

              <form onSubmit={handleUpdatePassword} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  {/* Current Password */}
                  <div className="space-y-1.5">
                    <label className="text-slate-300 font-bold">كلمة المرور الحالية</label>
                    <div className="relative">
                      <input
                        type={showCurrentPassword ? 'text' : 'password'}
                        required
                        value={passwordData.current_password}
                        onChange={(e) => setPasswordData({ ...passwordData, current_password: e.target.value })}
                        placeholder="••••••••"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-amber-500 text-white font-medium focus:outline-none text-xs pr-3.5 pl-9 text-left font-mono"
                        dir="ltr"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                        className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                      >
                        {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* New Password */}
                  <div className="space-y-1.5">
                    <label className="text-slate-300 font-bold">كلمة المرور الجديدة</label>
                    <div className="relative">
                      <input
                        type={showNewPassword ? 'text' : 'password'}
                        required
                        value={passwordData.new_password}
                        onChange={(e) => setPasswordData({ ...passwordData, new_password: e.target.value })}
                        placeholder="••••••••"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-amber-500 text-white font-medium focus:outline-none text-xs pr-3.5 pl-9 text-left font-mono"
                        dir="ltr"
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                        className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                      >
                        {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Confirm Password */}
                  <div className="space-y-1.5">
                    <label className="text-slate-300 font-bold">تأكيد كلمة المرور</label>
                    <div className="relative">
                      <input
                        type={showConfirmPassword ? 'text' : 'password'}
                        required
                        value={passwordData.new_password_confirmation}
                        onChange={(e) => setPasswordData({ ...passwordData, new_password_confirmation: e.target.value })}
                        placeholder="••••••••"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-amber-500 text-white font-medium focus:outline-none text-xs pr-3.5 pl-9 text-left font-mono"
                        dir="ltr"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                      >
                        {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Password Strength Tip */}
                <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
                  <span>💡 يوصى بكلمة مرور تحتوي على 8 أحرف على الأقل، تتضمن أرقاماً ورموزاً لضمان حماية بيانات المرضى.</span>
                  {passwordData.new_password && (
                    <span className={`font-bold font-mono px-2 py-0.5 rounded ${
                      passwordData.new_password.length >= 8 ? 'text-emerald-400 bg-emerald-500/10' : 'text-amber-400 bg-amber-500/10'
                    }`}>
                      {passwordData.new_password.length >= 8 ? 'قوية 🛡️' : 'مقبولة ⚠️'}
                    </span>
                  )}
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="submit"
                    disabled={savingPassword}
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white text-xs font-black transition flex items-center space-x-2 space-x-reverse shadow-lg shadow-amber-600/20 disabled:opacity-50"
                  >
                    <Key className="w-4 h-4" />
                    <span>{savingPassword ? 'جاري التحديث...' : 'تحديث كلمة المرور'}</span>
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* RIGHT/SIDEBAR: Practitioner Security Card & Info (4 Cols) */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-xl">
              <div className="flex items-center space-x-3 space-x-reverse border-b border-slate-800 pb-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white font-black text-lg shadow-lg shadow-indigo-500/20">
                  {profileData.name ? profileData.name.charAt(0) : 'Ψ'}
                </div>
                <div>
                  <h3 className="font-black text-white text-sm">{profileData.name || 'حساب المختص'}</h3>
                  <p className="text-[11px] text-indigo-400 font-mono font-bold truncate max-w-[180px]">
                    {profileData.email}
                  </p>
                </div>
              </div>

              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-400">الرتبة في المنظومة</span>
                  <span className="font-bold text-white px-2.5 py-0.5 rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    {profileData.role === 'clinic_admin' || profileData.role === 'admin'
                      ? 'مدير العيادة (Clinic Admin)'
                      : 'أخصائي معالج (Specialist)'}
                  </span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-400">العيادة المرتبطة</span>
                  <span className="font-bold text-emerald-400 truncate max-w-[160px]">
                    {tenant?.name || 'ClinicSaaS DZ'}
                  </span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-400">حالة التشفير والحماية</span>
                  <span className="font-bold text-emerald-400 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>256-bit AES</span>
                  </span>
                </div>
              </div>

              {/* Compliance Note */}
              <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-500/20 text-[11px] text-slate-300 space-y-1.5 leading-relaxed">
                <div className="font-bold text-indigo-300 flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-indigo-400" />
                  <span>بروتوكول الأمان السريري</span>
                </div>
                <p>
                  يتم تشفير كلمات المرور وسجلات الجلسات وفق معايير الحماية الطبية العالمية. لا يتم مشاركة بيانات الدخول مع أي طرف خارجي.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
