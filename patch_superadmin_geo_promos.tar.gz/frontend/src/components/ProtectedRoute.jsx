import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import TenantLoginView from './auth/TenantLoginView';
import PublicClinicBookingLandingView from './portal/PublicClinicBookingLandingView';
import LandingPageView from './public/LandingPageView';
import { isSubdomain } from '../utils/subdomain';

export default function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  const token = localStorage.getItem('token') || localStorage.getItem('clinic_token');
  const onSubdomain = isSubdomain();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-slate-400 font-sans">
        <div className="space-y-3 text-center">
          <div className="animate-spin w-8 h-8 border-2 border-teal-400 border-t-transparent rounded-full mx-auto" />
          <div className="text-xs font-mono text-slate-500">جاري التحقق من الجلسة السحابية...</div>
        </div>
      </div>
    );
  }

  if (!user && !token) {
    // If visitor is on a clinic subdomain:
    if (onSubdomain) {
      // If staff explicitly visits /login or /admin -> show the staff login screen
      if (location.pathname === '/login' || location.pathname === '/admin' || location.pathname === '/auth') {
        return <TenantLoginView />;
      }
      // Otherwise (visiting root / or any public page) -> show the Clinic Landing Page & Online Booking directly!
      return <PublicClinicBookingLandingView />;
    }

    // On root platform domain (psypro.tech) -> If visiting root '/' or '/landing', show the public SaaS Landing Page
    if (location.pathname === '/' || location.pathname === '/landing') {
      return <LandingPageView />;
    }

    // Otherwise attempting to access protected dashboard/clinical routes -> navigate to login
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  return children;
}
